# tsvio

R package for reading (subsets of) tsv files

To install and load this package into R:

```
install.packages("devtools")
library(devtools)
devtools::install_github("MD-Anderson-Bioinformatics/tsvio")
library(tsvio)
```


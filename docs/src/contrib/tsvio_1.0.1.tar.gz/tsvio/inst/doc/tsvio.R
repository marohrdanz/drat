## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- results='hide', message=FALSE, warning=FALSE, eval=FALSE----------------
#  tsvGenIndex (filename, indexfile)

## ---- results='hide', message=FALSE, warning=FALSE, eval=FALSE----------------
#  tsvGetData (filename, indexfile, rowpatterns, colpatterns, dtype="", findany=TRUE)

## ---- results='hide', message=FALSE, warning=FALSE, eval=FALSE----------------
#  tsvGetLines (filename, indexfile, patterns, findany=TRUE)


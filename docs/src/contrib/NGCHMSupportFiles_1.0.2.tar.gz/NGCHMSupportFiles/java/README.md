The source-code for the Java and Javascript files in this package are available from the Next-Generation Clustered Heat Maps github site https://github.com/MD-Anderson-Bioinformatics/NG-CHM.
Instructions for building the files in this package are given in the README.md for this package.
